import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { User } from "../models/user.model.js";
import { ApiResponse } from "../utils/ApiResponse.js";

const registerUser = asyncHandler(async(req,res)=>{

    //*Get user details from request body
    const {username, email, password, fullName} = req.body;
    console.log(req.body);

    //*Validate user
    if([username, email,password,fullName].some((field)=>field?.trim()==="")){
        throw new ApiError(400, "All fields are required!");
    }

    //*Check if user already exists
    const existedUser = await User.findOne({
        $or: [{username},{email}]
    });

    if(existedUser){
        throw new ApiError(409, "User with email or username already exists!");
    }

    //*Create new user object and save to db
    const user  = await User.create({
        fullName,
        username: username.toLowerCase(),
        email,
        password
    });

    //*Remove password from the response
    const createdUser = await User.findById(user._id).select("-password");

    if(!createdUser) {
        throw new ApiError(500, "Something went wrong while registering the user");
    }

    //*return response
    return res
    .status(201)
    .json(
        new ApiResponse(201, createdUser, "User Registered Successfully!")
    );
});

export {registerUser};